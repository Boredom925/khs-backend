/* =============================================
   KOLKATA HIGH SCHOOL — script.js
   (with backend API integration)
   ============================================= */

// ─── CONFIG: Change this to your Vercel URL after deploying ──────
const API_BASE = 'https://your-project.vercel.app/api';
// During local dev: const API_BASE = 'http://localhost:5000/api';

const SCHOOL_LAT = 22.5786;
const SCHOOL_LNG = 88.4195;
const MAX_DISTANCE_KM = 5;

let userDistanceKm = null;
let userLocationCleared = null;
let mapInitialized = false;

// ─── PAGE NAVIGATION ────────────────────────────────────────────
const navLinks = document.querySelectorAll('.nav-link');
const pages = document.querySelectorAll('.page');

function switchPage(pageName) {
  pages.forEach(p => p.classList.remove('active'));
  navLinks.forEach(l => l.classList.remove('active'));
  const targetPage = document.getElementById('page-' + pageName);
  if (targetPage) targetPage.classList.add('active');
  navLinks.forEach(l => { if (l.dataset.page === pageName) l.classList.add('active'); });
  window.scrollTo({ top: 0, behavior: 'smooth' });
  document.getElementById('mobileNav').classList.remove('open');
  if (pageName === 'notice') loadNotices();
}

navLinks.forEach(link => {
  link.addEventListener('click', (e) => { e.preventDefault(); switchPage(link.dataset.page); });
});

document.getElementById('hamburger').addEventListener('click', () => {
  document.getElementById('mobileNav').classList.toggle('open');
});

// ─── MODAL ──────────────────────────────────────────────────────
const admissionModal = document.getElementById('admissionModal');

document.getElementById('applyBtn').addEventListener('click', () => {
  admissionModal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  if (!mapInitialized) { initSchoolMap(); mapInitialized = true; }
  document.getElementById('locationResult').classList.add('hidden');
  document.getElementById('admissionMsg').classList.add('hidden');
  const btn = document.getElementById('checkLocationBtn');
  btn.disabled = false;
  btn.textContent = '📡 Check My Location (GPS)';
  userDistanceKm = null; userLocationCleared = null;
});

document.getElementById('modalClose').addEventListener('click', closeModal);
admissionModal.addEventListener('click', (e) => { if (e.target === admissionModal) closeModal(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

function closeModal() {
  admissionModal.classList.add('hidden');
  document.body.style.overflow = '';
}

// ─── LEAFLET MAP ────────────────────────────────────────────────
function initSchoolMap() {
  const map = L.map('schoolMap').setView([SCHOOL_LAT, SCHOOL_LNG], 14);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors', maxZoom: 18
  }).addTo(map);
  const schoolIcon = L.divIcon({
    html: `<div style="background:#0d2b55;color:#f0d080;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;border:3px solid #c9a84c;box-shadow:0 2px 10px rgba(0,0,0,0.3)">🏫</div>`,
    iconSize: [38, 38], iconAnchor: [19, 19], className: ''
  });
  L.marker([SCHOOL_LAT, SCHOOL_LNG], { icon: schoolIcon }).addTo(map)
    .bindPopup('<strong>Kolkata High School</strong><br/>12, School Road, Salt Lake, Sector V<br/>Kolkata — 700091').openPopup();
  L.circle([SCHOOL_LAT, SCHOOL_LNG], {
    radius: 5000, color: '#0d2b55', fillColor: '#daeeff',
    fillOpacity: 0.12, weight: 2, dashArray: '6,4'
  }).addTo(map);
}

// ─── GPS CHECK ──────────────────────────────────────────────────
document.getElementById('checkLocationBtn').addEventListener('click', () => {
  const btn = document.getElementById('checkLocationBtn');
  const resultDiv = document.getElementById('locationResult');
  const msgDiv = document.getElementById('admissionMsg');

  if (!navigator.geolocation) {
    resultDiv.classList.remove('hidden');
    resultDiv.textContent = 'Geolocation is not supported by your browser.';
    return;
  }

  btn.disabled = true; btn.textContent = 'Fetching location...';
  resultDiv.classList.add('hidden'); msgDiv.classList.add('hidden');

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const d = haversineDistance(SCHOOL_LAT, SCHOOL_LNG, pos.coords.latitude, pos.coords.longitude);
      userDistanceKm = parseFloat(d.toFixed(2));
      userLocationCleared = d <= MAX_DISTANCE_KM;

      resultDiv.classList.remove('hidden');
      resultDiv.innerHTML = `📍 Location detected. Distance from school: <strong>${userDistanceKm} km</strong>`;
      btn.textContent = '✅ Location Checked';

      msgDiv.classList.remove('hidden');
      msgDiv.className = 'admission-msg';

      if (!userLocationCleared) {
        msgDiv.classList.add('denied');
        msgDiv.innerHTML = `❌ <strong>Resident more than 5 km — Cannot be admitted.</strong><br/>Your residence is ${userDistanceKm} km from the school, exceeding the 5 km limit. Contact the admissions office for special consideration.`;
      } else {
        msgDiv.classList.add('cleared');
        msgDiv.innerHTML = `
          ✅ <strong>Cleared for Admission!</strong><br/>
          Your residence is only ${userDistanceKm} km away — within the eligible zone.<br/><br/>
          📋 Please visit on any <strong>working day (Mon–Sat, 9 AM – 2 PM)</strong> with:<br/>
          <ul style="margin-top:8px;padding-left:18px;line-height:2">
            <li>Child's last Report Card</li><li>Aadhaar Card (child's & parent's)</li><li>Birth Certificate</li>
          </ul>
          <button class="gps-btn" id="proceedAdmissionBtn" style="margin-top:14px">📝 Submit Admission Inquiry →</button>
        `;
        document.getElementById('proceedAdmissionBtn').addEventListener('click', showAdmissionForm);
      }
    },
    (err) => {
      btn.disabled = false; btn.textContent = '📡 Check My Location (GPS)';
      resultDiv.classList.remove('hidden');
      const msgs = { 1: '🚫 Location access denied. Allow location permission and try again.', 2: '📡 Location unavailable. Check your device settings.', 3: '⏱️ Request timed out. Try again.' };
      resultDiv.textContent = msgs[err.code] || 'Unable to detect location.';
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
  );
});

// ─── ADMISSION FORM ─────────────────────────────────────────────
function showAdmissionForm() {
  const msgDiv = document.getElementById('admissionMsg');
  msgDiv.innerHTML = `
    <strong style="display:block;margin-bottom:14px;color:#145a32">📝 Admission Inquiry Form</strong>
    <div style="display:grid;gap:10px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <input id="af-child" class="form-input" placeholder="Child's Full Name *" style="margin:0"/>
        <input id="af-parent" class="form-input" placeholder="Parent's Full Name *" style="margin:0"/>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <input id="af-email" class="form-input" type="email" placeholder="Email Address *" style="margin:0"/>
        <input id="af-phone" class="form-input" placeholder="10-digit Mobile Number *" style="margin:0"/>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <select id="af-class" class="form-input" style="margin:0">
          <option value="">-- Applying for Class --</option>
          ${['LKG','UKG','I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'].map(c => `<option value="${c}">${['LKG','UKG'].includes(c) ? c : 'Class ' + c}</option>`).join('')}
        </select>
        <input id="af-address" class="form-input" placeholder="Residential Address *" style="margin:0"/>
      </div>
      <button class="gps-btn" id="submitAdmissionBtn" style="margin-top:4px">Submit Inquiry ✉️</button>
      <div id="af-error" style="color:#c0392b;font-size:13px;display:none"></div>
      <div id="af-success" style="display:none;background:#e8f8ee;color:#145a32;padding:12px;border-radius:8px;border-left:4px solid #1a7a4a;font-size:14px"></div>
    </div>
  `;
  document.getElementById('submitAdmissionBtn').addEventListener('click', submitAdmission);
}

async function submitAdmission() {
  const btn = document.getElementById('submitAdmissionBtn');
  const errDiv = document.getElementById('af-error');
  const successDiv = document.getElementById('af-success');
  const payload = {
    childName: document.getElementById('af-child').value.trim(),
    parentName: document.getElementById('af-parent').value.trim(),
    email: document.getElementById('af-email').value.trim(),
    phone: document.getElementById('af-phone').value.trim(),
    applyingForClass: document.getElementById('af-class').value,
    address: document.getElementById('af-address').value.trim(),
    distanceFromSchoolKm: userDistanceKm,
    locationCleared: userLocationCleared,
  };
  const required = ['childName','parentName','email','phone','applyingForClass','address'];
  if (required.some(k => !payload[k])) {
    errDiv.textContent = 'Please fill all required fields.';
    errDiv.style.display = 'block'; return;
  }
  errDiv.style.display = 'none';
  btn.disabled = true; btn.textContent = '⏳ Submitting...';
  try {
    const res = await fetch(`${API_BASE}/admission`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      btn.style.display = 'none';
      successDiv.style.display = 'block';
      successDiv.innerHTML = `✅ <strong>Inquiry submitted!</strong><br/>Reference ID: <code>${data.referenceId}</code><br/>A confirmation email has been sent to <strong>${payload.email}</strong>. We'll contact you within 2–3 working days.`;
    } else {
      errDiv.textContent = data.errors ? data.errors.map(e => e.msg).join(', ') : data.message;
      errDiv.style.display = 'block';
      btn.disabled = false; btn.textContent = 'Submit Inquiry ✉️';
    }
  } catch (e) {
    errDiv.textContent = 'Network error. Please check your connection.';
    errDiv.style.display = 'block';
    btn.disabled = false; btn.textContent = 'Submit Inquiry ✉️';
  }
}

// ─── NOTICES FROM API ───────────────────────────────────────────
async function loadNotices() {
  const board = document.querySelector('.notice-board');
  if (!board) return;
  board.innerHTML = '<p style="text-align:center;color:#888;padding:30px">⏳ Loading notices...</p>';
  try {
    const res = await fetch(`${API_BASE}/notices`);
    const data = await res.json();
    if (!data.success || !data.data.length) {
      board.innerHTML = '<p style="text-align:center;color:#888;padding:30px">No notices at the moment.</p>'; return;
    }
    board.innerHTML = data.data.map(n => {
      const date = new Date(n.publishedAt).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
      return `
        <div class="notice-card ${n.isUrgent ? 'urgent' : ''}">
          <div class="notice-meta">
            <span class="notice-tag ${n.isUrgent ? 'urgent-tag' : ''}">${n.isUrgent ? '🔴' : '📢'} ${n.tag}</span>
            <span class="notice-date">${date}</span>
          </div>
          <h3>${n.title}</h3>
          <p>${n.body}</p>
        </div>`;
    }).join('');
  } catch (e) {
    board.innerHTML = `<div class="notice-card"><p>⚠️ Could not load live notices. Showing default content.</p></div>
      <div class="notice-card urgent"><div class="notice-meta"><span class="notice-tag urgent-tag">🔴 Urgent</span><span class="notice-date">25 Mar 2025</span></div><h3>Admission Form Last Date Extended</h3><p>The last date for Session 2025–26 has been extended to <strong>15 April 2025</strong>.</p></div>`;
  }
}

// ─── HAVERSINE ──────────────────────────────────────────────────
function haversineDistance(lat1, lng1, lat2, lng2) {
  const R = 6371, dLat = toRad(lat2-lat1), dLng = toRad(lng2-lng1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}
function toRad(d) { return d * Math.PI / 180; }

// ─── ACADEMICS TABS ─────────────────────────────────────────────
document.querySelectorAll('.ac-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.ac-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.ac-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
  });
});

// ─── FACILITIES DROPDOWNS ───────────────────────────────────────
document.querySelectorAll('.facility-toggle').forEach(toggle => {
  toggle.addEventListener('click', () => {
    const body = document.getElementById(toggle.dataset.target);
    const isOpen = body.classList.contains('open');
    document.querySelectorAll('.facility-body').forEach(b => b.classList.remove('open'));
    document.querySelectorAll('.facility-toggle').forEach(t => t.classList.remove('open'));
    if (!isOpen) { body.classList.add('open'); toggle.classList.add('open'); }
  });
});

// ─── CONTACT FORM ───────────────────────────────────────────────
document.getElementById('submitMsg').addEventListener('click', async () => {
  const btn = document.getElementById('submitMsg');
  const successDiv = document.getElementById('formSuccess');
  const payload = {
    name:    document.querySelector('.form-input[placeholder="Your Name"]').value.trim(),
    email:   document.querySelector('.form-input[placeholder="Email Address"]').value.trim(),
    subject: document.querySelector('.form-input[placeholder="Subject"]').value.trim(),
    message: document.querySelector('.form-textarea').value.trim(),
  };
  if (Object.values(payload).some(v => !v)) {
    document.querySelectorAll('.form-input, .form-textarea').forEach(i => {
      if (!i.value.trim()) { i.style.borderColor = '#e74c3c'; setTimeout(() => i.style.borderColor = '', 2000); }
    }); return;
  }
  btn.disabled = true; btn.textContent = '⏳ Sending...';
  try {
    const res = await fetch(`${API_BASE}/contact`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      successDiv.classList.remove('hidden');
      successDiv.textContent = '✅ ' + data.message;
      document.querySelectorAll('.form-input, .form-textarea').forEach(i => i.value = '');
      setTimeout(() => successDiv.classList.add('hidden'), 8000);
    } else {
      alert('Error: ' + (data.errors ? data.errors.map(e => e.msg).join(', ') : data.message));
    }
  } catch (e) {
    alert('Network error. Please try again.');
  } finally {
    btn.disabled = false; btn.textContent = 'Send Message ✉️';
  }
});
